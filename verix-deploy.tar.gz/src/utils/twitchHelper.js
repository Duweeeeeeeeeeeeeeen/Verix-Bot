import axios from 'axios';
import logger from './logger.js';

let accessToken = null;
let tokenExpires = 0;

/**
 * Fetches the Twitch App Access Token using Client ID and Secret.
 */
async function getAccessToken() {
    const clientId = process.env.TWITCH_CLIENT_ID;
    const clientSecret = process.env.TWITCH_CLIENT_SECRET;

    if (!clientId || !clientSecret || clientId.includes('your_') || clientSecret.includes('your_')) {
        logger.error('[Twitch] Missing or placeholder TWITCH_CLIENT_ID or TWITCH_CLIENT_SECRET in .env');
        return null;
    }

    // Return cached token if still valid
    if (accessToken && Date.now() < tokenExpires) {
        return accessToken;
    }

    try {
        const response = await axios.post('https://id.twitch.tv/oauth2/token', null, {
            params: {
                client_id: clientId,
                client_secret: clientSecret,
                grant_type: 'client_credentials'
            }
        });

        accessToken = response.data.access_token;
        // Set expiry slightly earlier than reported (usually 2 months, but better be safe)
        tokenExpires = Date.now() + (response.data.expires_in - 60) * 1000;
        
        logger.info('[Twitch] Successfully refreshed App Access Token.');
        return accessToken;
    } catch (error) {
        logger.error('[Twitch] Error fetching access token:', error.response?.data || error.message);
        return null;
    }
}

/**
 * Cleans a list of strings (usernames or Twitch URLs) into plain Twitch usernames.
 * @param {string[]} inputs 
 * @returns {string[]}
 */
function cleanTwitchUsernames(inputs) {
    return inputs.map(u => {
        if (!u) return '';
        const trimmed = u.trim();
        if (trimmed.includes('twitch.tv/')) {
            const parts = trimmed.split('/');
            return parts[parts.length - 1].split('?')[0].trim();
        }
        return trimmed;
    }).filter(u => u.length > 0);
}

/**
 * Fetches stream data for multiple usernames.
 * @param {string[]} usernames List of Twitch usernames or URLs.
 */
export async function getStreams(usernames) {
    const cleanNames = cleanTwitchUsernames(usernames);
    if (!cleanNames.length) return [];
    
    const token = await getAccessToken();
    if (!token) return [];

    try {
        const streamRes = await axios.get('https://api.twitch.tv/helix/streams', {
            headers: {
                'Client-ID': process.env.TWITCH_CLIENT_ID,
                'Authorization': `Bearer ${token}`
            },
            params: {
                user_login: cleanNames
            }
        });

        if (!streamRes.data || !streamRes.data.data) {
            logger.error('[TwitchHelper] Unexpected API response structure:', streamRes.data);
            return [];
        }

        return streamRes.data.data;
    } catch (error) {
        logger.error('[TwitchHelper] Error fetching streams:', error.response?.data || error.message);
        return null; // Return null to indicate error
    }
}

/**
 * Fetches user data for multiple usernames (for profile pictures).
 * @param {string[]} usernames List of Twitch usernames or URLs.
 */
export async function getUsers(usernames) {
    const cleanNames = cleanTwitchUsernames(usernames);
    if (!cleanNames.length) return [];
    
    const token = await getAccessToken();
    if (!token) return [];

    try {
        const userRes = await axios.get('https://api.twitch.tv/helix/users', {
            headers: {
                'Client-ID': process.env.TWITCH_CLIENT_ID,
                'Authorization': `Bearer ${token}`
            },
            params: {
                login: cleanNames
            }
        });

        return userRes.data?.data || [];
    } catch (error) {
        logger.error('[TwitchHelper] Error fetching users:', error.response?.data || error.message);
        return null; // Return null to indicate error
    }
}

/**
 * Gets the static URL for a stream thumbnail with timestamp to bypass Discord cache.
 */
export function getThumbnailUrl(username) {
    return `https://static-cdn.jtvnw.net/previews-ttv/live_user_${username.toLowerCase()}-1280x720.jpg?t=${Date.now()}`;
}
